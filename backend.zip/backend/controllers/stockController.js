const { NseIndia } = require("stock-nse-india");
const { GoogleGenAI } = require("@google/genai");
const StockUser = require("../models/alertPrice");

// ============================================================
// NSE
// ============================================================

const nseIndia = new NseIndia();

// ============================================================
// GEMINI
// ============================================================

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

// ============================================================
// GET CURRENT STOCK PRICE
// GET /stock/:id
// ============================================================

const getStockPrice = async (req, res) => {
  const stockID = req.params.id;

  if (!stockID) {
    return res.status(400).json({
      message: "Stock ID is required",
    });
  }

  try {
    const details = await nseIndia.getEquityDetails(stockID.toUpperCase());

    if (
      details &&
      details.priceInfo &&
      details.priceInfo.lastPrice !== undefined
    ) {
      return res.status(200).json(details);
    }

    return res.status(404).json({
      message: "Stock details not found",
    });
  } catch (error) {
    console.error(`Error fetching stock ${stockID}:`, error.message);

    return res.status(500).json({
      message: error.message || "Failed to fetch stock details",
    });
  }
};

// ============================================================
// SET STOCK PRICE LIMIT
// POST /stock/alert
// ============================================================

const setStockLimit = async (req, res) => {
  const { name, email, stock } = req.body;

  if (!name || !email || !stock) {
    return res.status(400).json({
      message: "All fields are required!",
    });
  }

  try {
    let user = await StockUser.findOne({ email });

    if (!user) {
      user = new StockUser({
        name,
        email,
        stock: [],
      });
    }

    const existingStock = user.stock.find((s) => s.stockId === stock.stockId);

    if (existingStock) {
      existingStock.targetPrice = stock.targetPrice;
      existingStock.stopLoss = stock.stopLoss;
    } else {
      user.stock.push(stock);
    }

    await user.save();

    return res.status(200).json({
      message: existingStock
        ? "Price Limits Updated Successfully"
        : "Price Limits Set Successfully",
    });
  } catch (error) {
    console.error("Set Stock Limit Error:", error);

    return res.status(500).json({
      message: "Error saving stock alert",
      error: error.message,
    });
  }
};

// ============================================================
// GET ALERTS BY EMAIL
// GET /stock/alert/:email
// ============================================================

const getAlertsByEmail = async (req, res) => {
  const { email } = req.params;

  if (!email) {
    return res.status(400).json({
      message: "Email is required",
    });
  }

  try {
    const alerts = await StockUser.find({ email });

    return res.status(200).json(alerts);
  } catch (error) {
    console.error("Error fetching alerts:", error.message);

    return res.status(500).json({
      message: "Failed to fetch alerts",
    });
  }
};

// ============================================================
// GET HISTORICAL DATA
// GET /stock/graph/:symbol
// ============================================================

const getHistory = async (req, res) => {
  const symbol = String(req.params.symbol || "")
    .trim()
    .toUpperCase();

  if (!symbol) {
    return res.status(400).json({
      error: "Stock symbol is required",
    });
  }

  try {
    console.log(`Fetching historical data for: ${symbol}`);

    const rawResult = await nseIndia.getEquityHistoricalData(symbol);

    console.log(
      `NSE historical response for ${symbol}:`,
      JSON.stringify(rawResult, null, 2),
    );

    if (!Array.isArray(rawResult)) {
      return res.status(502).json({
        error: "Invalid historical data received from NSE",
      });
    }

    const candles = [];

    for (const segment of rawResult) {
      if (!segment || !Array.isArray(segment.data)) {
        continue;
      }

      for (const d of segment.data) {
        if (!d) continue;

        const dateValue =
          d.CH_TIMESTAMP || d.CH_TIMESTAMP_DATE || d.TIMESTAMP || d.date;

        const open = Number(d.CH_OPENING_PRICE);
        const high = Number(d.CH_TRADE_HIGH_PRICE);
        const low = Number(d.CH_TRADE_LOW_PRICE);
        const close = Number(d.CH_CLOSING_PRICE);

        if (
          !dateValue ||
          !Number.isFinite(open) ||
          !Number.isFinite(high) ||
          !Number.isFinite(low) ||
          !Number.isFinite(close)
        ) {
          continue;
        }

        const timestamp = Math.floor(new Date(dateValue).getTime() / 1000);

        if (!Number.isFinite(timestamp) || timestamp <= 0) {
          continue;
        }

        candles.push({
          time: timestamp,
          open,
          high,
          low,
          close,
        });
      }
    }

    candles.sort((a, b) => a.time - b.time);

    // Remove duplicate timestamps
    const uniqueCandles = [];
    const seen = new Set();

    for (const candle of candles) {
      if (seen.has(candle.time)) {
        continue;
      }

      seen.add(candle.time);
      uniqueCandles.push(candle);
    }

    console.log(`${symbol}: ${uniqueCandles.length} valid candles`);

    if (uniqueCandles.length === 0) {
      return res.status(502).json({
        error: `No historical data available for ${symbol}`,
      });
    }

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "application/json");

    return res.status(200).json(uniqueCandles);
  } catch (error) {
    console.error(
      `Historical data error for ${symbol}:`,
      error.response?.data || error.message,
    );

    const status = error.response?.status || 500;

    return res.status(status === 403 ? 502 : 500).json({
      error:
        error.response?.data?.message ||
        error.response?.data?.error ||
        error.message ||
        "Failed to fetch historical data",
    });
  }
};

// ============================================================
// AI STOCK PREDICTION
// POST /stock/ai/predict
// ============================================================

const aiPredict = async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured.",
      });
    }

    const input = req.body || {};

    const companyName =
      input["Issuer Name"] ||
      input["Security Name"] ||
      input.name ||
      "Unknown company";

    const securityId =
      input["Security Id"] || input.symbol || input.stockId || "";

    /*
     * If the frontend sends current price information,
     * give it to Gemini.
     */
    const currentPrice =
      input.priceInfo?.lastPrice ||
      input.currentPrice ||
      input.lastPrice ||
      null;

    const stockInformation = {
      companyName,
      securityId,
      currentPrice,
      stockData: input,
    };

    const prompt = `
You are an AI financial analyst for StockViewAI.

Analyze the following stock:

${JSON.stringify(stockInformation, null, 2)}

You may use Google Search to find recent publicly available information
about the company.

Prefer reliable sources such as:
- NSE India
- BSE India
- company official website
- company annual reports
- reputable financial news sources
- Chittorgarh when relevant for IPO/company information

Return ONLY a valid JSON object.

The JSON must have exactly these fields:

{
  "pros": [
    "short key strength",
    "short key strength"
  ],
  "cons": [
    "short key weakness",
    "short key weakness"
  ],
  "recommendation": "buy",
  "bestBuyPrice": 0,
  "bestSellPrice": 0,
  "summary": "short human-friendly company overview"
}

Rules:

1. recommendation must be exactly:
   "buy"
   "sell"
   or
   "hold"

2. bestBuyPrice must be a number.

3. bestSellPrice must be a number.

4. pros must be an array of strings.

5. cons must be an array of strings.

6. summary must be a short string.

7. Do not use Markdown.

8. Do not add text outside the JSON object.

9. If a reliable current market price is available, use it when
   determining buy/sell levels.

10. If a current market price is NOT available, do not pretend
    that you know the exact current price.

11. Do not guarantee future returns.

12. Keep the response short and practical.

13. This is informational analysis, not a guarantee of investment returns.
`;

    // ========================================================
    // GEMINI INTERACTIONS API
    // ========================================================

    const interaction = await ai.interactions.create({
      model: "gemini-3.6-flash",

      input: prompt,

      tools: [
        {
          type: "google_search",
        },
      ],
    });

    const text = interaction.output_text;

    if (!text) {
      console.error("Empty Gemini response:", interaction);

      return res.status(500).json({
        error: "No content received from Gemini.",
      });
    }

    console.log("Gemini AI response:", text);

    // ========================================================
    // PARSE JSON
    // ========================================================

    let parsed;

    try {
      parsed = JSON.parse(text);
    } catch (error) {
      console.error("Gemini returned invalid JSON:", text);

      // Remove Markdown code fences if Gemini adds them
      const cleaned = text
        .replace(/^```json\s*/i, "")
        .replace(/^```\s*/i, "")
        .replace(/\s*```$/i, "")
        .trim();

      try {
        parsed = JSON.parse(cleaned);
      } catch (secondError) {
        return res.status(500).json({
          error: "Gemini returned invalid JSON.",
        });
      }
    }

    // ========================================================
    // NORMALIZE RESPONSE
    // ========================================================

    const recommendation = String(
      parsed.recommendation || "hold",
    ).toLowerCase();

    const finalRecommendation = ["buy", "sell", "hold"].includes(recommendation)
      ? recommendation
      : "hold";

    const bestBuyPrice = Number(parsed.bestBuyPrice);

    const bestSellPrice = Number(parsed.bestSellPrice);

    return res.status(200).json({
      pros: Array.isArray(parsed.pros) ? parsed.pros : [],

      cons: Array.isArray(parsed.cons) ? parsed.cons : [],

      recommendation: finalRecommendation,

      bestBuyPrice: Number.isFinite(bestBuyPrice)
        ? Number(bestBuyPrice.toFixed(2))
        : 0,

      bestSellPrice: Number.isFinite(bestSellPrice)
        ? Number(bestSellPrice.toFixed(2))
        : 0,

      summary:
        typeof parsed.summary === "string"
          ? parsed.summary
          : "No company overview available.",
    });
  } catch (error) {
    console.error("AI Predict Error:", error);

    return res.status(500).json({
      error: error?.message || "Failed to get prediction from Gemini AI.",
    });
  }
};

// ============================================================
// ASK AI
// POST /stock/ask/ai
// ============================================================

const askAI = async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        result: "GEMINI_API_KEY is not configured.",
      });
    }

    const { question } = req.body || {};

    if (!question || typeof question !== "string" || !question.trim()) {
      return res.status(400).json({
        result: "No question provided.",
      });
    }

    const prompt = `
You are StockViewAI, an AI financial assistant.

Answer the user's financial question clearly and concisely.

Question:
${question.trim()}

Rules:
- Give factual and useful information.
- If the question concerns current information, use Google Search.
- Do not guarantee investment returns.
- Do not claim certainty about future stock prices.
- Keep the answer easy to understand.
`;

    const interaction = await ai.interactions.create({
      model: "gemini-3.6-flash",

      input: prompt,

      tools: [
        {
          type: "google_search",
        },
      ],
    });

    const text = interaction.output_text;

    if (!text) {
      return res.status(500).json({
        result: "No answer received from Gemini.",
      });
    }

    return res.status(200).json({
      result: text,
    });
  } catch (error) {
    console.error("Ask AI Error:", error);

    return res.status(500).json({
      result: error?.message || "AI Error",
    });
  }
};

// ============================================================
// EXPORT
// ============================================================

module.exports = {
  getStockPrice,
  setStockLimit,
  getAlertsByEmail,
  getHistory,
  aiPredict,
  askAI,
};
